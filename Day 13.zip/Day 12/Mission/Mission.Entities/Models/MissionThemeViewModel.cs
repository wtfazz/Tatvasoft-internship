﻿namespace Mission.Entities.Models
{
    public class MissionThemeViewModel
    {
        public int Id { get; set; }
        public string ThemeName { get; set; }
        public string Status { get; set; }
    }
}
